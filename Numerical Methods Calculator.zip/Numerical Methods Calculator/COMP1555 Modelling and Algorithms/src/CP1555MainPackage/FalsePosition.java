//author Ds2182y
package CP1555MainPackage;

//imports
import GraphData.MultiGraph;
import java.applet.Applet;
import java.awt.Dimension;
import java.text.DecimalFormat;
import javax.swing.JOptionPane;

public class FalsePosition extends javax.swing.JFrame {

    public FalsePosition() {
        initComponents();

         /* 
        
         The code below is responsible for disabling objects when the frame is first opened.
        
         */
        
        // Text boxes
        boxsp1.setEnabled(false); // x0
        boxsp2.setEnabled(false); // x1
        boxPre.setEnabled(false); // Decimal Places
        //Buttons
        buttonCal.setEnabled(false); // Calculate
        buttonGraph.setEnabled(false); // Graph
        buttonReset.setEnabled(false); //Reset
        buttonClear.setEnabled(false);  //Clear
        //Labels
        labelsp1.setEnabled(false); // "x0" label
        labelsp2.setEnabled(false); // "x1" label
        labelpre.setEnabled(false); // "Decimal Places" label
        labelIterations.setEnabled(false); // "No. of Iterations" label
        //Spinner
        iterationsSelect.setEnabled(false); //Spinner

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonReset = new javax.swing.JButton();
        buttonGraph = new javax.swing.JButton();
        labelTitle = new javax.swing.JLabel();
        boxsp1 = new javax.swing.JTextField();
        boxPre = new javax.swing.JTextField();
        boxsp2 = new javax.swing.JTextField();
        buttonExit = new javax.swing.JButton();
        labelsp1 = new javax.swing.JLabel();
        buttonBack = new javax.swing.JButton();
        panelFunctions = new javax.swing.JPanel();
        f2 = new javax.swing.JRadioButton();
        f1 = new javax.swing.JRadioButton();
        f3 = new javax.swing.JRadioButton();
        labelsp2 = new javax.swing.JLabel();
        labelpre = new javax.swing.JLabel();
        buttonCal = new javax.swing.JButton();
        labelIterations = new javax.swing.JLabel();
        iterationsSelect = new javax.swing.JSpinner();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtAnswer = new javax.swing.JTextArea();
        buttonClear = new javax.swing.JButton();
        labelsp4 = new javax.swing.JLabel();
        labelsp5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        buttonReset.setText(" Reset All");
        buttonReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonResetActionPerformed(evt);
            }
        });

        buttonGraph.setText("Graph");
        buttonGraph.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonGraphActionPerformed(evt);
            }
        });

        labelTitle.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        labelTitle.setText("False-Position Method");

        boxsp1.setText("0");
        boxsp1.setInheritsPopupMenu(true);
        boxsp1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxsp1ActionPerformed(evt);
            }
        });
        boxsp1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                boxsp1KeyTyped(evt);
            }
        });

        boxPre.setText("0.00");
        boxPre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxPreActionPerformed(evt);
            }
        });

        boxsp2.setText("0");
        boxsp2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxsp2ActionPerformed(evt);
            }
        });

        buttonExit.setBackground(new java.awt.Color(153, 0, 0));
        buttonExit.setForeground(new java.awt.Color(204, 204, 204));
        buttonExit.setText("Exit");
        buttonExit.setToolTipText("Exit the application");
        buttonExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonExitActionPerformed(evt);
            }
        });

        labelsp1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        labelsp1.setText("x0 =");

        buttonBack.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        buttonBack.setText("Back");
        buttonBack.setToolTipText("Back to main menu");
        buttonBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonBackActionPerformed(evt);
            }
        });

        panelFunctions.setBackground(new java.awt.Color(204, 204, 204));
        panelFunctions.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        f2.setBackground(new java.awt.Color(204, 204, 204));
        f2.setForeground(new java.awt.Color(0, 0, 0));
        f2.setText("ln(x+1)+1");
        f2.setToolTipText("Function 2");
        f2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                f2ActionPerformed(evt);
            }
        });

        f1.setBackground(new java.awt.Color(204, 204, 204));
        f1.setForeground(new java.awt.Color(0, 0, 0));
        f1.setText("x-x^2");
        f1.setToolTipText("Function 1");
        f1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                f1ActionPerformed(evt);
            }
        });

        f3.setBackground(new java.awt.Color(204, 204, 204));
        f3.setForeground(new java.awt.Color(0, 0, 0));
        f3.setText("e^x-3x");
        f3.setToolTipText("Function 3");
        f3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                f3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelFunctionsLayout = new javax.swing.GroupLayout(panelFunctions);
        panelFunctions.setLayout(panelFunctionsLayout);
        panelFunctionsLayout.setHorizontalGroup(
            panelFunctionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelFunctionsLayout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(f1)
                .addGap(71, 71, 71)
                .addComponent(f2)
                .addGap(73, 73, 73)
                .addComponent(f3)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelFunctionsLayout.setVerticalGroup(
            panelFunctionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelFunctionsLayout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(panelFunctionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(f1)
                    .addComponent(f2)
                    .addComponent(f3))
                .addContainerGap(45, Short.MAX_VALUE))
        );

        labelsp2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        labelsp2.setText("X1 =");

        labelpre.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        labelpre.setText("Decimal Places:");

        buttonCal.setText("Calculate");
        buttonCal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonCalActionPerformed(evt);
            }
        });

        labelIterations.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        labelIterations.setText("No. of Iterations:");

        iterationsSelect.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));
        iterationsSelect.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        iterationsSelect.setName(""); // NOI18N
        iterationsSelect.setValue(1);

        txtAnswer.setColumns(20);
        txtAnswer.setRows(5);
        jScrollPane1.setViewportView(txtAnswer);
        txtAnswer.setEditable(false);

        buttonClear.setText("Clear");
        buttonClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonClearActionPerformed(evt);
            }
        });

        labelsp4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        labelsp4.setText("--------------------------------------FUNCTIONS-----------------------------------");

        labelsp5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        labelsp5.setText("------------------------------------SETTINGS--------------------------------------");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(buttonExit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(buttonGraph, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(panelFunctions, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addGap(53, 53, 53)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(labelsp1)
                                                .addComponent(labelsp2)
                                                .addComponent(labelpre)
                                                .addComponent(labelIterations))
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(layout.createSequentialGroup()
                                                    .addGap(44, 44, 44)
                                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                        .addComponent(boxPre, javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(boxsp1, javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(boxsp2, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(iterationsSelect, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGap(64, 64, 64))))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                            .addComponent(buttonCal, javax.swing.GroupLayout.PREFERRED_SIZE, 356, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(buttonClear, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGap(3, 3, 3))
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(20, 20, 20)
                                    .addComponent(buttonBack, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(labelTitle)
                                    .addGap(12, 12, 12))
                                .addComponent(labelsp4))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(labelsp5)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(buttonReset, javax.swing.GroupLayout.DEFAULT_SIZE, 439, Short.MAX_VALUE)
                            .addComponent(jScrollPane1))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(labelTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(buttonBack))
                        .addGap(18, 18, 18)
                        .addComponent(labelsp4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(panelFunctions, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(labelsp5, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(boxsp1, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labelsp1))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(labelsp2)
                            .addComponent(boxsp2, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(boxPre, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labelpre))
                        .addGap(20, 20, 20)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(labelIterations)
                                .addGap(21, 21, 21))
                            .addComponent(iterationsSelect, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(buttonCal, javax.swing.GroupLayout.DEFAULT_SIZE, 97, Short.MAX_VALUE)
                            .addComponent(buttonClear, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(13, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 564, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(buttonGraph, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                    .addComponent(buttonReset, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(buttonExit, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void buttonResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonResetActionPerformed

        //Text Boxes
        boxsp1.setEnabled(false); //x0
        boxsp2.setEnabled(false); //x1
        boxPre.setEnabled(false); //Decimal Places
        //Buttons
        buttonCal.setEnabled(false); //Calculate
        buttonGraph.setEnabled(false); //Graph
        buttonReset.setEnabled(false); //Reset
        buttonClear.setEnabled(false); //Clear
        //Labels
        labelsp1.setEnabled(false); //"x0" label
        labelsp2.setEnabled(false); //"x1" label
        labelpre.setEnabled(false); //"Decimal Places" label
        //Deselects all radiobuttons
        f1.setSelected(false); // x-x^2
        f2.setSelected(false); // ln(x+1)+1
        f3.setSelected(false); // e^x-3x
        //Enables all radiobittons
        f1.setEnabled(true); // x-x^2
        f2.setEnabled(true); // ln(x+1)+1
        f3.setEnabled(true); // e^x-3x
        //Setting both text areas to show nothing
        txtAnswer.setText(""); // Root
        //Set values for text boxes
        boxsp1.setText("0"); //Sets x0 text box to value "0"
        boxsp2.setText("0"); //Sets x1 text box to value "0"
        boxPre.setText("0.00"); //Sets Decimal Places text box to value "0.00"

    }//GEN-LAST:event_buttonResetActionPerformed

    private void buttonGraphActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonGraphActionPerformed

        //This code launches the graph and activates the classes stored in the "Graph" Packages
        javax.swing.JFrame f = new javax.swing.JFrame();
        Applet app = new MultiGraph();
        app.init();
        f.setTitle("Function Plotter"); // set title for graph frame
        f.getContentPane().add(app);
        f.pack();
        f.setSize(new Dimension(1200, 800)); // set dimensions for graph frame
        f.setVisible(true);
    }//GEN-LAST:event_buttonGraphActionPerformed

    //------------ -----------------------------------------------------------------------------------//
    // False-Position Algorithm START                                                                 //
    //------------------------------------------------------------------------------------------------//
    static double func(double x) {
        //if functions to determine which function to return based on user selection via radiobuttons
        if (f3.isSelected()) {
            return Math.exp(x) - 3 * x; //e^x-3x
        } else {
            if (f2.isSelected()) {
                return Math.log(x + 1) + 1; //ln(x+1)+1
            } else {
                if (f1.isSelected()) {

                }
            }

        }
        return x - x * x; //x-x^2
    }

    static void fpm(double x0, double x1) {

        int iterNum = 1;    // how many times secant has been performed 

        double f0, f1, f2;  // function values /

        double x2;          // new point for function evaluation 
        //  to print numbers with 8 digits behind the decimal point 

        DecimalFormat df = new DecimalFormat((boxPre.getText()));
        double tolerance = 0.0000001;   /* indicates smallest possible interval
         width to search */

        int maxIterations = (int) iterationsSelect.getValue();  /* the maximum number of times to do
         the false position method */

        txtAnswer.append("X0\tX1\tX2\tF(X2)"); // \t is a tab

        do {
            f0 = func(x0);
            f1 = func(x1);
            x2 = x1 - f1 * (x0 - x1) / (f0 - f1);
            f2 = func(x2);
            txtAnswer.append("\t\n\t\n" + df.format(x0) + "\t"
                    + df.format(x1) + "\t" + df.format(x2) + "\t"
                    + df.format(f2));
            if ((f2 > 0 && f0 < 0) || (f2 < 0 && f0 > 0)) {
                x1 = x2;
            } else {
                x0 = x2;
            }
            iterNum++;          // current iteration has been completed
        } while (Math.abs(f2) >= tolerance && iterNum <= maxIterations);

    }

    public static void fp(javax.swing.JTextArea area) {
        fpm(Double.parseDouble(boxsp1.getText()), Double.parseDouble(boxsp2.getText())); // Receives input from text boxes x0 and x1
    }

    //----------------------------------------------------------------------------------------------// 
    // False-Position Algorithm END                                                                 //
    //----------------------------------------------------------------------------------------------//

    private void boxsp1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxsp1ActionPerformed
        // No code stored
    }//GEN-LAST:event_boxsp1ActionPerformed

    private void boxsp1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_boxsp1KeyTyped
        // No code stored
    }//GEN-LAST:event_boxsp1KeyTyped

    private void boxsp2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxsp2ActionPerformed
        // No code stored
    }//GEN-LAST:event_boxsp2ActionPerformed

    private void buttonExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonExitActionPerformed
        System.exit(0); // Terminates the program
    }//GEN-LAST:event_buttonExitActionPerformed

    private void buttonBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonBackActionPerformed

        //Code for back to menu button
        FalsePosition fp = new FalsePosition();
        Menu m = new Menu();
        m.setVisible(true); // set visibitiy for menu frame
        m.setLocationRelativeTo(null); //set location for menu frame
        m.setTitle("Numerical Methods"); // set title for menu frame
        fp.setVisible(false); // terminates current frame
        dispose(); // terminates current frame

    }//GEN-LAST:event_buttonBackActionPerformed

    private void f2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_f2ActionPerformed

        if (f2.isSelected()) { //ln(x+1)+1
            //Text boxes
            boxsp1.setEnabled(true); // x0
            boxsp2.setEnabled(true); // x1
            boxPre.setEnabled(true); // Decimal Places
            //Buttons
            buttonCal.setEnabled(true); // Calculate
            buttonGraph.setEnabled(true); // Graph
            buttonReset.setEnabled(true); // Reset
            buttonClear.setEnabled(true); // Clear
            //Labels
            labelsp1.setEnabled(true); // "x0" label
            labelsp2.setEnabled(true); // "x1" label
            labelpre.setEnabled(true); // "Decimal Places" label
            labelIterations.setEnabled(true); // "No. of Iterations" label
            //Spinner
            iterationsSelect.setEnabled(true); //Spinner
            //Radio buttons
            f1.setEnabled(false); //x-x^2
            f3.setEnabled(false); //e^x-3x
            //Setting text area to show nothing
            txtAnswer.setText(""); //Root

        } else {
            //Text boxes
            boxsp1.setEnabled(false); // x0
            boxsp2.setEnabled(false); // x1
            boxPre.setEnabled(false); //Decimal Places
            //Buttons
            buttonCal.setEnabled(false); // Calculate
            buttonGraph.setEnabled(false); // Graph
            buttonReset.setEnabled(false); // Reset
            buttonClear.setEnabled(false); // Clear
            //Labels
            labelsp1.setEnabled(false); // "x0" label
            labelsp2.setEnabled(false); // "x1" label
            labelpre.setEnabled(false); // "Decimal Places" label
            labelIterations.setEnabled(false); // "No. of Iterations" label
            //Spinner
            iterationsSelect.setEnabled(false); //Spinner
            //Radio buttons
            f1.setEnabled(true); //x-x^2
            f3.setEnabled(true); //e^x-3x
            //Setting text area to show nothing
            txtAnswer.setText(""); //Root

    }//GEN-LAST:event_f2ActionPerformed
    }
    private void f1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_f1ActionPerformed

        if (f1.isSelected()) { //x-x^2
            //Text boxes
            boxsp1.setEnabled(true); // x0
            boxsp2.setEnabled(true); // x1
            boxPre.setEnabled(true); // Decimal Places
            //Buttons
            buttonCal.setEnabled(true); // Calculate
            buttonGraph.setEnabled(true); // Graph
            buttonReset.setEnabled(true); // Reset
            buttonClear.setEnabled(true); // Clear
            //Labels
            labelsp1.setEnabled(true); // "x0" label
            labelsp2.setEnabled(true); // "x1" label
            labelpre.setEnabled(true); // "Decimal Places" label
            labelIterations.setEnabled(true); // "No. of Iterations" label
            //Spinner
            iterationsSelect.setEnabled(true); //Spinner
            //Radio buttons
            f2.setEnabled(false); //ln(x+1)+1
            f3.setEnabled(false); //e^x-3x
            //Setting text area to show nothing
            txtAnswer.setText(""); //Root

        } else {
            //Text boxes
            boxsp1.setEnabled(false); // x0
            boxsp2.setEnabled(false); // x1
            boxPre.setEnabled(false); //Decimal Places
            //Buttons
            buttonCal.setEnabled(false); // Calculate
            buttonGraph.setEnabled(false); // Graph
            buttonReset.setEnabled(false); // Reset
            buttonClear.setEnabled(false); // Clear
            //Labels
            labelsp1.setEnabled(false); // "x0" label
            labelsp2.setEnabled(false); // "x1" label
            labelpre.setEnabled(false); // "Decimal Places" label
            labelIterations.setEnabled(false); // "No. of Iterations" label
            //Spinner
            iterationsSelect.setEnabled(false); //Spinner
            //Radio buttons
            f2.setEnabled(true); //ln(x+1)+1
            f3.setEnabled(true); //e^x-3x
            //Setting text area to show nothing
            txtAnswer.setText(""); //Root

        }
    }//GEN-LAST:event_f1ActionPerformed

    private void f3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_f3ActionPerformed

        if (f3.isSelected()) { //e^x-3x
            //Text boxes
            boxsp1.setEnabled(true); // x0
            boxsp2.setEnabled(true); // x1
            boxPre.setEnabled(true); // Decimal Places
            //Buttons
            buttonCal.setEnabled(true); // Calculate
            buttonGraph.setEnabled(true); // Graph
            buttonReset.setEnabled(true); // Reset
            buttonClear.setEnabled(true); // Clear
            //Labels
            labelsp1.setEnabled(true); // "x0" label
            labelsp2.setEnabled(true); // "x1" label
            labelpre.setEnabled(true); // "Decimal Places" label
            labelIterations.setEnabled(true); // "No. of Iterations" label
            //Spinner
            iterationsSelect.setEnabled(true); //Spinner
            //Radio buttons
            f1.setEnabled(false); //x-x^2
            f2.setEnabled(false); //ln(x+1)+1
            //Setting text area to show nothing
            txtAnswer.setText(""); //Root

        } else {
            //Text boxes
            boxsp1.setEnabled(false); // x0
            boxsp2.setEnabled(false); // x1
            boxPre.setEnabled(false); //Decimal Places
            //Buttons
            buttonCal.setEnabled(false); // Calculate
            buttonGraph.setEnabled(false); // Graph
            buttonReset.setEnabled(false); // Reset
            buttonClear.setEnabled(false); // Clear
            //Labels
            labelsp1.setEnabled(false); // "x0" label
            labelsp2.setEnabled(false); // "x1" label
            labelpre.setEnabled(false); // "Decimal Places" label
            labelIterations.setEnabled(false); // "No. of Iterations" label
            //Spinner
            iterationsSelect.setEnabled(false); //Spinner
            //Radio buttons
            f1.setEnabled(true); //x-x^2
            f2.setEnabled(true); //ln(x+1)+1
            //Setting  text area to show nothing
            txtAnswer.setText(""); //Root

        }
    }//GEN-LAST:event_f3ActionPerformed

    private void buttonCalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonCalActionPerformed
        //User input valdation
           if (boxsp1.getText().equals("")) { //x0
            JOptionPane.showMessageDialog(null, "Please enter starting point(s) "); // Message box to inform the user
        } else {
            if (boxsp2.getText().equals("")) { // x1
                JOptionPane.showMessageDialog(null, "Please enter starting point(s) "); // Message box to inform the user
            } else {
                if (boxPre.getText().equals("")) { // Decimal Places
                    boxsp1.setText(""); // If decimal place box is empty, this line intentionally removes the first starting point to stop the calculation from happening.
                    JOptionPane.showMessageDialog(null, "Please enter decimal places & re-enter first starting point "); // Message box to inform the user
                } else {
                }
            }
        }
          
        fp(txtAnswer); // runs false-position algorithm

        //Text boxes
        boxsp1.setEnabled(false); // x0
        boxsp2.setEnabled(false); // x1 
        boxPre.setEnabled(false); // Decimal Places
        //Buttons
        buttonCal.setEnabled(false); // Calcualte
        buttonGraph.setEnabled(false); // Graph
        //labels
        labelsp1.setEnabled(false); // "x0" label
        labelsp2.setEnabled(false); // "x1" label 
        labelpre.setEnabled(false); // "Decimal Places" label
        labelIterations.setEnabled(false); // ""No. of Iterations" label
        //Spinner
        iterationsSelect.setEnabled(false); //Spinner
    }//GEN-LAST:event_buttonCalActionPerformed

    private void boxPreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxPreActionPerformed
        if (boxPre.getText().equals("1")) {

        }
    }//GEN-LAST:event_boxPreActionPerformed

    private void buttonClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonClearActionPerformed

        //Text boxes
        boxsp1.setEnabled(true); // x0
        boxsp2.setEnabled(true); // x1
        boxPre.setEnabled(true); // Decimal Places
        //Buttons
        buttonCal.setEnabled(true); // Calculate
        buttonGraph.setEnabled(true); // Graph
        buttonReset.setEnabled(true); // Reset
        buttonClear.setEnabled(true); // Clear
        //Labels
        labelsp1.setEnabled(true); // "x0" label
        labelsp2.setEnabled(true); // "x1" label
        labelpre.setEnabled(true); // "Decimal Places" label
        labelIterations.setEnabled(true); // "No. of Iterations" label
        //Spinner
        iterationsSelect.setEnabled(true); // Spinner
        //Setting both text areas to show nothing
        txtAnswer.setText(""); // Root

    }//GEN-LAST:event_buttonClearActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FalsePosition.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FalsePosition.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FalsePosition.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FalsePosition.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FalsePosition().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private static javax.swing.JTextField boxPre;
    private static javax.swing.JTextField boxsp1;
    private static javax.swing.JTextField boxsp2;
    private javax.swing.JButton buttonBack;
    private javax.swing.JButton buttonCal;
    private javax.swing.JButton buttonClear;
    private javax.swing.JButton buttonExit;
    private javax.swing.JButton buttonGraph;
    private javax.swing.JButton buttonReset;
    private static javax.swing.JRadioButton f1;
    private static javax.swing.JRadioButton f2;
    private static javax.swing.JRadioButton f3;
    private static javax.swing.JSpinner iterationsSelect;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labelIterations;
    private javax.swing.JLabel labelTitle;
    private javax.swing.JLabel labelpre;
    private javax.swing.JLabel labelsp1;
    private javax.swing.JLabel labelsp2;
    private javax.swing.JLabel labelsp4;
    private javax.swing.JLabel labelsp5;
    private javax.swing.JPanel panelFunctions;
    private static javax.swing.JTextArea txtAnswer;
    // End of variables declaration//GEN-END:variables
}
