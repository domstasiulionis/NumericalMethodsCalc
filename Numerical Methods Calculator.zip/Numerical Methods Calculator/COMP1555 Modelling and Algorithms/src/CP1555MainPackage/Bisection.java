//author Ds2182y
package CP1555MainPackage;

//imports
import GraphData.MultiGraph;
import java.applet.Applet;
import java.awt.Dimension;
import java.text.DecimalFormat;
import java.util.Arrays;
import javax.swing.JOptionPane;

public class Bisection extends javax.swing.JFrame {

    //Declaring array
    //'200' is the amount of data it will store and can be modified
    Object[] bisectiondata = new Object[200];

    public Bisection() {
        initComponents();

        /* 
        
         The code below is responsible for disabling objects when the frame is first opened.
        
         */
        
        // Text boxes
        boxsp1.setEnabled(false); // x0
        boxsp2.setEnabled(false); // x1
        boxPre.setEnabled(false); // Decimal Places
        //Buttons
        buttonCal.setEnabled(false); // Calculate
        buttonGraph.setEnabled(false); // Graph
        buttonReset.setEnabled(false); //Reset
        buttonClear.setEnabled(false);  //Clear
        //Labels
        labelsp1.setEnabled(false); // "x0" label
        labelsp2.setEnabled(false); // "x1" label
        labelpre.setEnabled(false); // "Decimal Places" label
        labelIterations.setEnabled(false); // "No. of Iterations" label
        //Spinner
        iterationsSelect.setEnabled(false); //Spinner

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        labelsp1 = new javax.swing.JLabel();
        buttonBack = new javax.swing.JButton();
        labelsp2 = new javax.swing.JLabel();
        labelpre = new javax.swing.JLabel();
        buttonCal = new javax.swing.JButton();
        buttonReset = new javax.swing.JButton();
        labelTitle = new javax.swing.JLabel();
        boxsp1 = new javax.swing.JTextField();
        boxPre = new javax.swing.JTextField();
        boxsp2 = new javax.swing.JTextField();
        buttonExit = new javax.swing.JButton();
        panelFunctions = new javax.swing.JPanel();
        f2 = new javax.swing.JRadioButton();
        f1 = new javax.swing.JRadioButton();
        f3 = new javax.swing.JRadioButton();
        buttonGraph = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtAnswer = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtAnswerIteration = new javax.swing.JTextArea();
        buttonClear = new javax.swing.JButton();
        labelsp4 = new javax.swing.JLabel();
        labelsp5 = new javax.swing.JLabel();
        iterationsSelect = new javax.swing.JSpinner();
        labelIterations = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        labelsp1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        labelsp1.setText("x0 =");

        buttonBack.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        buttonBack.setText("Back");
        buttonBack.setToolTipText("Back to the main menu");
        buttonBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonBackActionPerformed(evt);
            }
        });

        labelsp2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        labelsp2.setText("x1 =");

        labelpre.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        labelpre.setText("Decimal Places:");

        buttonCal.setText("Calculate");
        buttonCal.setToolTipText("Starts calculation");
        buttonCal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonCalActionPerformed(evt);
            }
        });

        buttonReset.setText("Reset");
        buttonReset.setToolTipText("Resets the window to default");
        buttonReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonResetActionPerformed(evt);
            }
        });

        labelTitle.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        labelTitle.setText("Bisection Method");

        boxsp1.setText("0");
        boxsp1.setToolTipText("Enter first starting point");
        boxsp1.setInheritsPopupMenu(true);
        boxsp1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxsp1ActionPerformed(evt);
            }
        });
        boxsp1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                boxsp1KeyTyped(evt);
            }
        });

        boxPre.setText("0.00");
        boxPre.setToolTipText("Adjust decimal places of final answer and iterations");
        boxPre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxPreActionPerformed(evt);
            }
        });

        boxsp2.setText("0");
        boxsp2.setToolTipText("Enter second starting point");
        boxsp2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxsp2ActionPerformed(evt);
            }
        });

        buttonExit.setBackground(new java.awt.Color(153, 0, 0));
        buttonExit.setForeground(new java.awt.Color(204, 204, 204));
        buttonExit.setText("Exit");
        buttonExit.setToolTipText("Exit the application");
        buttonExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonExitActionPerformed(evt);
            }
        });

        panelFunctions.setBackground(new java.awt.Color(204, 204, 204));
        panelFunctions.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        f2.setBackground(new java.awt.Color(204, 204, 204));
        f2.setForeground(new java.awt.Color(0, 0, 0));
        f2.setText("ln(x+1)+1");
        f2.setToolTipText("Fucntion 2");
        f2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                f2ActionPerformed(evt);
            }
        });

        f1.setBackground(new java.awt.Color(204, 204, 204));
        f1.setForeground(new java.awt.Color(0, 0, 0));
        f1.setText("x-x^2");
        f1.setToolTipText("Fucntion 1");
        f1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                f1ActionPerformed(evt);
            }
        });

        f3.setBackground(new java.awt.Color(204, 204, 204));
        f3.setForeground(new java.awt.Color(0, 0, 0));
        f3.setText("e^x-3x");
        f3.setToolTipText("Fucntion 3");
        f3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                f3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelFunctionsLayout = new javax.swing.GroupLayout(panelFunctions);
        panelFunctions.setLayout(panelFunctionsLayout);
        panelFunctionsLayout.setHorizontalGroup(
            panelFunctionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelFunctionsLayout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(f1)
                .addGap(88, 88, 88)
                .addComponent(f2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(f3)
                .addGap(31, 31, 31))
        );
        panelFunctionsLayout.setVerticalGroup(
            panelFunctionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelFunctionsLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(panelFunctionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(f2)
                    .addComponent(f1)
                    .addComponent(f3))
                .addContainerGap(31, Short.MAX_VALUE))
        );

        buttonGraph.setText("Graph");
        buttonGraph.setToolTipText("Opens graph");
        buttonGraph.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonGraphActionPerformed(evt);
            }
        });

        txtAnswer.setColumns(20);
        txtAnswer.setRows(5);
        txtAnswer.setToolTipText("Final Root");
        jScrollPane2.setViewportView(txtAnswer);
        txtAnswer.setEditable(false);

        txtAnswerIteration.setColumns(20);
        txtAnswerIteration.setRows(5);
        txtAnswerIteration.setToolTipText("Iterations");
        jScrollPane3.setViewportView(txtAnswerIteration);
        txtAnswerIteration.setEditable(false);

        buttonClear.setText("Clear");
        buttonClear.setToolTipText("Clear content in all text boxes");
        buttonClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonClearActionPerformed(evt);
            }
        });

        labelsp4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        labelsp4.setText("-----------------------------------------FUNCTIONS--------------------------------------");

        labelsp5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        labelsp5.setText("------------------------------------------SETTINGS---------------------------------------");

        iterationsSelect.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));
        iterationsSelect.setToolTipText("adjust how many iterations you would like to see");
        iterationsSelect.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        iterationsSelect.setName(""); // NOI18N
        iterationsSelect.setValue(1);

        labelIterations.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        labelIterations.setText("No. of Iterations:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(buttonExit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(labelsp4)
                            .addComponent(buttonGraph, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(174, 174, 174)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(boxsp2, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(boxPre, javax.swing.GroupLayout.DEFAULT_SIZE, 297, Short.MAX_VALUE)
                                    .addComponent(boxsp1, javax.swing.GroupLayout.Alignment.LEADING)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(36, 36, 36)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(labelsp1)
                                            .addComponent(labelsp2)
                                            .addComponent(labelpre)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(labelIterations)
                                                .addGap(99, 99, 99)
                                                .addComponent(iterationsSelect, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(buttonCal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                .addComponent(buttonClear, javax.swing.GroupLayout.DEFAULT_SIZE, 120, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(buttonBack, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(37, 37, 37)
                                .addComponent(labelTitle))
                            .addComponent(panelFunctions, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(labelsp5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 380, Short.MAX_VALUE)
                            .addComponent(buttonReset, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jScrollPane2))))
                .addGap(15, 15, 15))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(7, 7, 7)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(buttonBack)
                            .addComponent(labelTitle, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(labelsp4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(panelFunctions, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(labelsp5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(boxsp1, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labelsp1))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(boxsp2, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labelsp2))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(boxPre, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labelpre))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(iterationsSelect, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labelIterations))
                        .addGap(31, 31, 31)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(buttonCal, javax.swing.GroupLayout.DEFAULT_SIZE, 97, Short.MAX_VALUE)
                            .addComponent(buttonClear, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(jScrollPane3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(buttonGraph, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                    .addComponent(buttonReset, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(buttonExit, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void buttonBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonBackActionPerformed

        //Code for back to menu button
        Bisection b = new Bisection();
        Menu m = new Menu();
        m.setVisible(true); // set visibitiy for menu frame
        m.setLocationRelativeTo(null); //set location for menu frame
        m.setTitle("Numerical Methods"); // set title for menu frame
        b.setVisible(false); // terminates current frame
        dispose(); // terminates current frame

    }//GEN-LAST:event_buttonBackActionPerformed

    //----------------------------------------------------------------------------------------------//
    // Bisection Algorithm START                                                                    //
    //----------------------------------------------------------------------------------------------// 
    public void bisec(javax.swing.JTextArea area) {
        DecimalFormat df = new DecimalFormat((boxPre.getText())); // delcares the use of decimal formatting and defines decimal format variable
        txtAnswer.setText("Root: " + " " + df.format(ans(Double.parseDouble(boxsp1.getText()), Double.parseDouble(boxsp2.getText())))); // Receives input from text boxes x0 and x1

    }
    private static final double Tol = 0.001; //Tolerance

    public double ans(double xUpper, double xLower) {

        DecimalFormat df = new DecimalFormat((boxPre.getText())); // delcares the use of decimal formatting and defines decimal format variable, receives input from text box Decimal Places
        int iteration;
        double x = 0;
        iteration = 0; //Iterations start at 0

        int maxIterations = (int) iterationsSelect.getValue(); //Determines amount of iterations displayed based user selecting from spinner

        //Calculations
        while (Math.abs(xUpper - xLower) > Tol && iteration <= maxIterations) {
            txtAnswerIteration.append("\nIteration " + iteration + ":   " + df.format(x));
            iteration += 1; //
            x = (xUpper + xLower) / 2;

            if (f(x) > 0) {
                xUpper = x;
            } else {
                xLower = x;
            }
            bisectiondata[iteration - 1] = df.format(x);
        }
        System.out.println(Arrays.toString(bisectiondata)); //prints data to the console
        return x;
    }

    private double f(double x) {
        //if functions to determine which function to return based on user selection via radiobuttons
        if (f3.isSelected()) {
            return Math.exp(x) - 3 * x; //e^x-3x
        } else {
            if (f2.isSelected()) {
                return Math.log(x + 1) + 1; //ln(x+1)+1
            } else {
                if (f1.isSelected()) {

                }
            }

        }
        return x - x * x; //x-x^2

    }

    //----------------------------------------------------------------------------------------------//
    // Bisection Algorithm END                                                                      //
    //----------------------------------------------------------------------------------------------//

    private void buttonCalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonCalActionPerformed
        //User input valdation
           if (boxsp1.getText().equals("")) { //x0
            JOptionPane.showMessageDialog(null, "Please enter starting point(s) "); // Message box to inform the user
        } else {
            if (boxsp2.getText().equals("")) { // x1
                JOptionPane.showMessageDialog(null, "Please enter starting point(s) "); // Message box to inform the user
            } else {
                if (boxPre.getText().equals("")) { // Decimal Places
                    boxsp1.setText(""); // If decimal place box is empty, this line intentionally removes the first starting point to stop the calculation from happening.
                    JOptionPane.showMessageDialog(null, "Please enter decimal places & re-enter first starting point "); // Message box to inform the user
                } else {
                }
            }
        }
          
        bisec(txtAnswer); // runs Bisection algorithm code

        //Text boxes
        boxsp1.setEnabled(false); // x0
        boxsp2.setEnabled(false); // x1 
        boxPre.setEnabled(false); // Decimal Places
        //Buttons
        buttonCal.setEnabled(false); // Calcualte
        buttonGraph.setEnabled(false); // Graph
        //labels
        labelsp1.setEnabled(false); // "x0" label
        labelsp2.setEnabled(false); // "x1" label 
        labelpre.setEnabled(false); // "Decimal Places" label
        labelIterations.setEnabled(false); // ""No. of Iterations" label
        //Spinner
        iterationsSelect.setEnabled(false); //Spinner


    }//GEN-LAST:event_buttonCalActionPerformed

    private void buttonResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonResetActionPerformed

        //Text Boxes
        boxsp1.setEnabled(false); //x0
        boxsp2.setEnabled(false); //x1
        boxPre.setEnabled(false); //Decimal Places
        //Buttons
        buttonCal.setEnabled(false); //Calculate
        buttonGraph.setEnabled(false); //Graph
        buttonReset.setEnabled(false); //Reset
        buttonClear.setEnabled(false); //Clear
        //Labels
        labelsp1.setEnabled(false); //"x0" label
        labelsp2.setEnabled(false); //"x1" label
        labelpre.setEnabled(false); //"Decimal Places" label
        labelIterations.setEnabled(false); // "No. of Iterations" label
        //Spinner
        iterationsSelect.setEnabled(false); // Spinner
        //Deselects all radiobuttons
        f1.setSelected(false); // x-x^2
        f2.setSelected(false); // ln(x+1)+1
        f3.setSelected(false); // e^x-3x
        //Enables all radiobittons
        f1.setEnabled(true); // x-x^2
        f2.setEnabled(true); // ln(x+1)+1
        f3.setEnabled(true); // e^x-3x
        //Setting both text areas to show nothing
        txtAnswer.setText(""); // Root
        txtAnswerIteration.setText(""); // Iterations
        //Set values for text boxes
        boxsp1.setText("0"); //Sets x0 text box to value "0"
        boxsp2.setText("0"); //Sets x1 text box to value "0"
        boxPre.setText("0.00"); //Sets Decimal Places text box to value "0.00"

    }//GEN-LAST:event_buttonResetActionPerformed

    private void boxsp1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxsp1ActionPerformed
        // No code stored
    }//GEN-LAST:event_boxsp1ActionPerformed

    private void buttonExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonExitActionPerformed
        System.exit(0); //Terminates the application
    }//GEN-LAST:event_buttonExitActionPerformed

    private void f2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_f2ActionPerformed

        if (f2.isSelected()) { //ln(x+1)+1
            //Text boxes
            boxsp1.setEnabled(true); // x0
            boxsp2.setEnabled(true); // x1
            boxPre.setEnabled(true); // Decimal Places
            //Buttons
            buttonCal.setEnabled(true); // Calculate
            buttonGraph.setEnabled(true); // Graph
            buttonReset.setEnabled(true); // Reset
            buttonClear.setEnabled(true); // Clear
            //Labels
            labelsp1.setEnabled(true); // "x0" label
            labelsp2.setEnabled(true); // "x1" label
            labelpre.setEnabled(true); // "Decimal Places" label
            labelIterations.setEnabled(true); // "No. of Iterations" label
            //Spinner
            iterationsSelect.setEnabled(true); //Spinner
            //Radio buttons
            f1.setEnabled(false); //x-x^2
            f3.setEnabled(false); //e^x-3x
            //Setting both text areas to show nothing
            txtAnswer.setText(""); //Root
            txtAnswerIteration.setText(""); //Iterations

        } else {
            //Text boxes
            boxsp1.setEnabled(false); // x0
            boxsp2.setEnabled(false); // x1
            boxPre.setEnabled(false); //Decimal Places
            //Buttons
            buttonCal.setEnabled(false); // Calculate
            buttonGraph.setEnabled(false); // Graph
            buttonReset.setEnabled(false); // Reset
            buttonClear.setEnabled(false); // Clear
            //Labels
            labelsp1.setEnabled(false); // "x0" label
            labelsp2.setEnabled(false); // "x1" label
            labelpre.setEnabled(false); // "Decimal Places" label
            labelIterations.setEnabled(false); // "No. of Iterations" label
            //Spinner
            iterationsSelect.setEnabled(false); //Spinner
            //Radio buttons
            f1.setEnabled(true); //x-x^2
            f3.setEnabled(true); //e^x-3x
            //Setting both text areas to show nothing
            txtAnswer.setText(""); //Root
            txtAnswerIteration.setText(""); //Iterations
        }

    }//GEN-LAST:event_f2ActionPerformed

    private void f1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_f1ActionPerformed

        if (f1.isSelected()) { //x-x^2
            //Text boxes
            boxsp1.setEnabled(true); // x0
            boxsp2.setEnabled(true); // x1
            boxPre.setEnabled(true); // Decimal Places
            //Buttons
            buttonCal.setEnabled(true); // Calculate
            buttonGraph.setEnabled(true); // Graph
            buttonReset.setEnabled(true); // Reset
            buttonClear.setEnabled(true); // Clear
            //Labels
            labelsp1.setEnabled(true); // "x0" label
            labelsp2.setEnabled(true); // "x1" label
            labelpre.setEnabled(true); // "Decimal Places" label
            labelIterations.setEnabled(true); // "No. of Iterations" label
            //Spinner
            iterationsSelect.setEnabled(true); //Spinner
            //Radio buttons
            f2.setEnabled(false); //ln(x+1)+1
            f3.setEnabled(false); //e^x-3x
            //Setting both text areas to show nothing
            txtAnswer.setText(""); //Root
            txtAnswerIteration.setText(""); //Iterations

        } else {
            //Text boxes
            boxsp1.setEnabled(false); // x0
            boxsp2.setEnabled(false); // x1
            boxPre.setEnabled(false); //Decimal Places
            //Buttons
            buttonCal.setEnabled(false); // Calculate
            buttonGraph.setEnabled(false); // Graph
            buttonReset.setEnabled(false); // Reset
            buttonClear.setEnabled(false); // Clear
            //Labels
            labelsp1.setEnabled(false); // "x0" label
            labelsp2.setEnabled(false); // "x1" label
            labelpre.setEnabled(false); // "Decimal Places" label
            labelIterations.setEnabled(false); // "No. of Iterations" label
            //Spinner
            iterationsSelect.setEnabled(false); //Spinner
            //Radio buttons
            f2.setEnabled(true); //ln(x+1)+1
            f3.setEnabled(true); //e^x-3x
            //Setting both text areas to show nothing
            txtAnswer.setText(""); //Root
            txtAnswerIteration.setText(""); //Iterations
        }
    }//GEN-LAST:event_f1ActionPerformed

    private void f3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_f3ActionPerformed

        if (f3.isSelected()) { //e^x-3x
            //Text boxes
            boxsp1.setEnabled(true); // x0
            boxsp2.setEnabled(true); // x1
            boxPre.setEnabled(true); // Decimal Places
            //Buttons
            buttonCal.setEnabled(true); // Calculate
            buttonGraph.setEnabled(true); // Graph
            buttonReset.setEnabled(true); // Reset
            buttonClear.setEnabled(true); // Clear
            //Labels
            labelsp1.setEnabled(true); // "x0" label
            labelsp2.setEnabled(true); // "x1" label
            labelpre.setEnabled(true); // "Decimal Places" label
            labelIterations.setEnabled(true); // "No. of Iterations" label
            //Spinner
            iterationsSelect.setEnabled(true); //Spinner
            //Radio buttons
            f1.setEnabled(false); //x-x^2
            f2.setEnabled(false); //ln(x+1)+1
            //Setting both text areas to show nothing
            txtAnswer.setText(""); //Root
            txtAnswerIteration.setText(""); //Iterations
        } else {
            //Text boxes
            boxsp1.setEnabled(false); // x0
            boxsp2.setEnabled(false); // x1
            boxPre.setEnabled(false); //Decimal Places
            //Buttons
            buttonCal.setEnabled(false); // Calculate
            buttonGraph.setEnabled(false); // Graph
            buttonReset.setEnabled(false); // Reset
            buttonClear.setEnabled(false); // Clear
            //Labels
            labelsp1.setEnabled(false); // "x0" label
            labelsp2.setEnabled(false); // "x1" label
            labelpre.setEnabled(false); // "Decimal Places" label
            labelIterations.setEnabled(false); // "No. of Iterations" label
            //Spinner
            iterationsSelect.setEnabled(false); //Spinner
            //Radio buttons
            f1.setEnabled(true); //x-x^2
            f2.setEnabled(true); //ln(x+1)+1
            //Setting both text areas to show nothing
            txtAnswer.setText(""); //Root
            txtAnswerIteration.setText(""); //Iterations
        }
    }//GEN-LAST:event_f3ActionPerformed

    private void buttonGraphActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonGraphActionPerformed

        //This code launches the graph and activates the classes stored in the "Graph" Packages
        javax.swing.JFrame f = new javax.swing.JFrame();
        Applet app = new MultiGraph();
        app.init();
        f.setTitle("Function Plotter"); // set title for graph frame
        f.getContentPane().add(app);
        f.pack();
        f.setSize(new Dimension(1200, 800)); // set dimensions for graph frame
        f.setVisible(true);

    }//GEN-LAST:event_buttonGraphActionPerformed

    private void boxsp1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_boxsp1KeyTyped
        // No code stored
    }//GEN-LAST:event_boxsp1KeyTyped

    private void boxsp2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxsp2ActionPerformed
        // No code stored
    }//GEN-LAST:event_boxsp2ActionPerformed

    private void boxPreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxPreActionPerformed
        // No code stored
    }//GEN-LAST:event_boxPreActionPerformed

    private void buttonClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonClearActionPerformed

        //Text boxes
        boxsp1.setEnabled(true); // x0
        boxsp2.setEnabled(true); // x1
        boxPre.setEnabled(true); // Decimal Places
        //Buttons
        buttonCal.setEnabled(true); // Calculate
        buttonGraph.setEnabled(true); // Graph
        buttonReset.setEnabled(true); // Reset
        buttonClear.setEnabled(true); // Clear
        //Labels
        labelsp1.setEnabled(true); // "x0" label
        labelsp2.setEnabled(true); // "x1" label
        labelpre.setEnabled(true); // "Decimal Places" label
        labelIterations.setEnabled(true); // "No. of Iterations" label
        //Spinner
        iterationsSelect.setEnabled(true); // Spinner
        //Setting both text areas to show nothing
        txtAnswer.setText(""); // Root
        txtAnswerIteration.setText(""); //Iterations
    }//GEN-LAST:event_buttonClearActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {


        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Bisection.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Bisection.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Bisection.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Bisection.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Bisection().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private static javax.swing.JTextField boxPre;
    private javax.swing.JTextField boxsp1;
    private javax.swing.JTextField boxsp2;
    private javax.swing.JButton buttonBack;
    private javax.swing.JButton buttonCal;
    private javax.swing.JButton buttonClear;
    private javax.swing.JButton buttonExit;
    private javax.swing.JButton buttonGraph;
    private javax.swing.JButton buttonReset;
    private javax.swing.JRadioButton f1;
    private javax.swing.JRadioButton f2;
    private javax.swing.JRadioButton f3;
    private static javax.swing.JSpinner iterationsSelect;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel labelIterations;
    private javax.swing.JLabel labelTitle;
    private javax.swing.JLabel labelpre;
    private javax.swing.JLabel labelsp1;
    private javax.swing.JLabel labelsp2;
    private javax.swing.JLabel labelsp4;
    private javax.swing.JLabel labelsp5;
    private javax.swing.JPanel panelFunctions;
    private javax.swing.JTextArea txtAnswer;
    private javax.swing.JTextArea txtAnswerIteration;
    // End of variables declaration//GEN-END:variables
}
