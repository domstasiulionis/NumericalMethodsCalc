//authour ds2182y
package CP1555MainPackage;

//imports
import GraphData.MultiGraph;
import java.applet.Applet;
import java.awt.Dimension;
import java.text.DecimalFormat;
import java.util.Arrays;
import javax.swing.JOptionPane;

public class Secant extends javax.swing.JFrame {

    //Declaring array
    //'200' is the amount of data it will store and can be modified
    static Object[] secantdata = new Object[200];

    /**
     * Creates new form Secant
     */
    public Secant() {

        initComponents();

        /* 
        
         The code below is responsible for disabling objects when the frame is first opened.
        
         */
        
        // Text boxes
        boxsp1.setEnabled(false); // x0
        boxsp2.setEnabled(false); // x1
        boxPre.setEnabled(false); // Decimal Places
        //Buttons
        buttonCal.setEnabled(false); // Calculate
        buttonGraph.setEnabled(false); // Graph
        buttonReset.setEnabled(false); //Reset
        buttonClear.setEnabled(false);  //Clear
        //Labels
        labelsp1.setEnabled(false); // "x0" label
        labelsp2.setEnabled(false); // "x1" label
        labelPre.setEnabled(false); // "Decimal Places" label
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        labelsp1 = new javax.swing.JLabel();
        labelsp2 = new javax.swing.JLabel();
        buttonCal = new javax.swing.JButton();
        labelTitle = new javax.swing.JLabel();
        buttonExit = new javax.swing.JButton();
        panelFunctions = new javax.swing.JPanel();
        f2 = new javax.swing.JRadioButton();
        f1 = new javax.swing.JRadioButton();
        f3 = new javax.swing.JRadioButton();
        buttonBack = new javax.swing.JButton();
        buttonReset = new javax.swing.JButton();
        boxsp1 = new javax.swing.JTextField();
        boxsp2 = new javax.swing.JTextField();
        buttonGraph = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtAnswer = new javax.swing.JTextArea();
        labelsp4 = new javax.swing.JLabel();
        labelsp5 = new javax.swing.JLabel();
        buttonClear = new javax.swing.JButton();
        boxPre = new javax.swing.JTextField();
        labelPre = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Secant Method");

        labelsp1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        labelsp1.setText("x0 =");

        labelsp2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        labelsp2.setText("x1=");

        buttonCal.setText("Calculate");
        buttonCal.setToolTipText("Starts Calculation");
        buttonCal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonCalActionPerformed(evt);
            }
        });

        labelTitle.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        labelTitle.setText("Secant Method");

        buttonExit.setBackground(new java.awt.Color(153, 0, 0));
        buttonExit.setForeground(new java.awt.Color(204, 204, 204));
        buttonExit.setText("Exit");
        buttonExit.setToolTipText("Exit the application");
        buttonExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonExitActionPerformed(evt);
            }
        });

        panelFunctions.setBackground(new java.awt.Color(204, 204, 204));
        panelFunctions.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        panelFunctions.setForeground(new java.awt.Color(0, 0, 0));

        f2.setBackground(new java.awt.Color(204, 204, 204));
        f2.setForeground(new java.awt.Color(0, 0, 0));
        f2.setText("ln(x+1)+1");
        f2.setToolTipText("Fucntion 2");
        f2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                f2ActionPerformed(evt);
            }
        });

        f1.setBackground(new java.awt.Color(204, 204, 204));
        f1.setForeground(new java.awt.Color(0, 0, 0));
        f1.setText("x-x^2");
        f1.setToolTipText("Fucntion 1");
        f1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                f1ActionPerformed(evt);
            }
        });

        f3.setBackground(new java.awt.Color(204, 204, 204));
        f3.setForeground(new java.awt.Color(0, 0, 0));
        f3.setText("e^x-3x");
        f3.setToolTipText("Fucntion 3");
        f3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                f3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelFunctionsLayout = new javax.swing.GroupLayout(panelFunctions);
        panelFunctions.setLayout(panelFunctionsLayout);
        panelFunctionsLayout.setHorizontalGroup(
            panelFunctionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelFunctionsLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(f1)
                .addGap(69, 69, 69)
                .addComponent(f2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 63, Short.MAX_VALUE)
                .addComponent(f3)
                .addGap(43, 43, 43))
        );
        panelFunctionsLayout.setVerticalGroup(
            panelFunctionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelFunctionsLayout.createSequentialGroup()
                .addContainerGap(23, Short.MAX_VALUE)
                .addGroup(panelFunctionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(f2)
                    .addComponent(f3)
                    .addComponent(f1))
                .addGap(23, 23, 23))
        );

        buttonBack.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        buttonBack.setText("Back");
        buttonBack.setToolTipText("Back to main menu");
        buttonBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonBackActionPerformed(evt);
            }
        });

        buttonReset.setText("Reset");
        buttonReset.setToolTipText("Resets the window to default");
        buttonReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonResetActionPerformed(evt);
            }
        });

        boxsp1.setText("0");
        boxsp1.setToolTipText("Enter first starting point");
        boxsp1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxsp1ActionPerformed(evt);
            }
        });

        boxsp2.setText("0");
        boxsp2.setToolTipText("Enter second starting point");
        boxsp2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxsp2ActionPerformed(evt);
            }
        });

        buttonGraph.setText("Graph");
        buttonGraph.setToolTipText("Opens graph");
        buttonGraph.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonGraphActionPerformed(evt);
            }
        });

        txtAnswer.setColumns(20);
        txtAnswer.setRows(5);
        txtAnswer.setToolTipText("Displays answers");
        jScrollPane1.setViewportView(txtAnswer);
        txtAnswer.setEditable(false);

        labelsp4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        labelsp4.setText("--------------------------------------FUNCTIONS--------------------------------");

        labelsp5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        labelsp5.setText("--------------------------------------SETTINGS----------------------------------");

        buttonClear.setText("Clear");
        buttonClear.setToolTipText("Clear content in all text boxes");
        buttonClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonClearActionPerformed(evt);
            }
        });

        boxPre.setText("0.00");
        boxPre.setToolTipText("Adjust decimal places of final answer and iterations");
        boxPre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxPreActionPerformed(evt);
            }
        });

        labelPre.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        labelPre.setText("Decimal Places");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(labelsp4)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(buttonBack, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(36, 36, 36)
                        .addComponent(labelTitle))
                    .addComponent(labelsp5)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(panelFunctions, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(532, 532, 532))
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(307, 307, 307)
                                    .addComponent(buttonClear, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(buttonGraph, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(labelsp1)
                                    .addComponent(labelsp2)
                                    .addComponent(labelPre))
                                .addGap(64, 64, 64)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(boxsp2)
                                    .addComponent(boxsp1, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(boxPre, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 500, Short.MAX_VALUE)
                            .addComponent(buttonReset, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(buttonCal, javax.swing.GroupLayout.PREFERRED_SIZE, 303, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buttonExit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(labelTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(buttonBack))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(labelsp4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(panelFunctions, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(labelsp5)
                        .addGap(40, 40, 40)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(boxsp1, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labelsp1))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(boxsp2, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labelsp2))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(boxPre, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labelPre))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(buttonCal, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(buttonClear, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 569, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(buttonGraph, javax.swing.GroupLayout.DEFAULT_SIZE, 52, Short.MAX_VALUE)
                    .addComponent(buttonReset, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(buttonExit, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public static void sec(javax.swing.JTextArea area) {
        //Variable declaration 
        double x0;
        double x1;
        double x;
        double pre = 0;
        int iteration = 0;

        x0 = Double.parseDouble(boxsp1.getText()); // First starting point is taken from x0 text box

        x1 = Double.parseDouble(boxsp2.getText()); // First starting point is taken from x1 text box

        DecimalFormat df = new DecimalFormat((boxPre.getText())); // Declaring decimal format variale

        if (function(x0) * function(x1) > 0.001d) {
            txtAnswer.append("Error"); // in case of an error or incalculable solution due to user input
            return;
        }
        x = x0;
        while (Math.abs(function(x)) > pre) {
            iteration += 1;
            txtAnswer.append("\n\n\tX: " + df.format(x) + "\n\tf(x): " + df.format((function(x))));
            df.format(x = x1 - ((function(x1) * (x1 - x0)) / (function(x1) - function(x0))));
            df.format(x0 = x1);
            df.format(x1 = x);
            secantdata[iteration - 1] = x;
        }
        System.out.println(Arrays.toString(secantdata)); // Prints Array data to console
    }

    private static double function(double x) {
        //if functions to determine which function to return based on user selection via radiobuttons
        if (f3.isSelected()) {
            return Math.exp(x) - 3 * x; // for x-x^2 function
        } else {
            if (f2.isSelected()) {
                return Math.log(x + 1) + 1; // ln(x+1)+1
            } else {
                if (f1.isSelected()) {

                }
            }

        }
        return x - x * x; // x-x^2
    }

    private void buttonCalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonCalActionPerformed

        //User input valdation
        if (boxsp1.getText().equals("")) { //x0
            JOptionPane.showMessageDialog(null, "Please enter starting point(s) "); // Message box to inform the user
        } else {
            if (boxsp2.getText().equals("")) { // x1
                JOptionPane.showMessageDialog(null, "Please enter starting point(s) "); // Message box to inform the user
            } else {
                if (boxPre.getText().equals("")) { // Decimal Places
                    boxsp1.setText(""); // If decimal place box is empty, this line intentionally removes the first starting point to stop the calculation from happening.
                    JOptionPane.showMessageDialog(null, "Please enter decimal places & re-enter first starting point "); // Message box to inform the user
                } else {
                }
            }
        }

        sec(txtAnswer);

        //Text boxes
        boxsp1.setEnabled(false); // x0
        boxsp2.setEnabled(false); // x1 
        boxPre.setEnabled(false); // Decimal Places
        //Buttons
        buttonCal.setEnabled(false); // Calcualte
        buttonGraph.setEnabled(false); // Graph
        //labels
        labelsp1.setEnabled(false); // "x0" label
        labelsp2.setEnabled(false); // "x1" label
        labelPre.setEnabled(false); // "Decimal Places" label

    }//GEN-LAST:event_buttonCalActionPerformed


    private void buttonExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonExitActionPerformed
        System.exit(0);
    }//GEN-LAST:event_buttonExitActionPerformed

    private void f2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_f2ActionPerformed
        if (f2.isSelected()) { //ln(x+1)+1
            //Text boxes
            boxsp1.setEnabled(true); // x0
            boxsp2.setEnabled(true); // x1
            boxPre.setEnabled(true); // Decimal Places
            //Buttons
            buttonCal.setEnabled(true); // Calculate
            buttonGraph.setEnabled(true); // Graph
            buttonReset.setEnabled(true); // Reset
            buttonClear.setEnabled(true); // Clear
            //Labels
            labelsp1.setEnabled(true); // "x0" label
            labelsp2.setEnabled(true); // "x1" label
            labelPre.setEnabled(true); // "Decimal Places" label
            //Radio buttons
            f1.setEnabled(false); //x-x^2
            f3.setEnabled(false); //e^x-3x
            //Setting text area to show nothing
            txtAnswer.setText(""); //Root

        } else {
            //Text boxes
            boxsp1.setEnabled(false); // x0
            boxsp2.setEnabled(false); // x1
            boxPre.setEnabled(false); //Decimal Places
            //Buttons
            buttonCal.setEnabled(false); // Calculate
            buttonGraph.setEnabled(false); // Graph
            buttonReset.setEnabled(false); // Reset
            buttonClear.setEnabled(false); // Clear
            //Labels
            labelsp1.setEnabled(false); // "x0" label
            labelsp2.setEnabled(false); // "x1" label
            labelPre.setEnabled(false); // "Decimal Places" label
            //Radio buttons
            f1.setEnabled(true); //x-x^2
            f3.setEnabled(true); //e^x-3x
            //Setting text area to show nothing
            txtAnswer.setText(""); //Root

        }
    }//GEN-LAST:event_f2ActionPerformed

    private void f1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_f1ActionPerformed

        if (f1.isSelected()) { //x-x^2
            //Text boxes
            boxsp1.setEnabled(true); // x0
            boxsp2.setEnabled(true); // x1
            boxPre.setEnabled(true); // Decimal Places
            //Buttons
            buttonCal.setEnabled(true); // Calculate
            buttonGraph.setEnabled(true); // Graph
            buttonReset.setEnabled(true); // Reset
            buttonClear.setEnabled(true); // Clear
            //Labels
            labelsp1.setEnabled(true); // "x0" label
            labelsp2.setEnabled(true); // "x1" label
            labelPre.setEnabled(true); // "Decimal Places" label
            //Radio buttons
            f2.setEnabled(false); //ln(x+1)+1
            f3.setEnabled(false); //e^x-3x
            //Setting text area to show nothing
            txtAnswer.setText(""); //Root

        } else {
            //Text boxes
            boxsp1.setEnabled(false); // x0
            boxsp2.setEnabled(false); // x1
            boxPre.setEnabled(false); //Decimal Places
            //Buttons
            buttonCal.setEnabled(false); // Calculate
            buttonGraph.setEnabled(false); // Graph
            buttonReset.setEnabled(false); // Reset
            buttonClear.setEnabled(false); // Clear
            //Labels
            labelsp1.setEnabled(false); // "x0" label
            labelsp2.setEnabled(false); // "x1" label
            labelPre.setEnabled(false); // "Decimal Places" label
            //Radio buttons
            f2.setEnabled(true); //ln(x+1)+1
            f3.setEnabled(true); //e^x-3x
            //Setting text area to show nothing
            txtAnswer.setText(""); //Root

        }
    }//GEN-LAST:event_f1ActionPerformed

    private void f3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_f3ActionPerformed
        if (f3.isSelected()) { //e^x-3x
            //Text boxes
            boxsp1.setEnabled(true); // x0
            boxsp2.setEnabled(true); // x1
            boxPre.setEnabled(true); // Decimal Places
            //Buttons
            buttonCal.setEnabled(true); // Calculate
            buttonGraph.setEnabled(true); // Graph
            buttonReset.setEnabled(true); // Reset
            buttonClear.setEnabled(true); // Clear
            //Labels
            labelsp1.setEnabled(true); // "x0" label
            labelsp2.setEnabled(true); // "x1" label
            labelPre.setEnabled(true); // "Decimal Places" label
            //Radio buttons
            f1.setEnabled(false); //x-x^2
            f2.setEnabled(false); //ln(x+1)+1
            //Setting text area to show nothing
            txtAnswer.setText(""); //Root

        } else {
            //Text boxes
            boxsp1.setEnabled(false); // x0
            boxsp2.setEnabled(false); // x1
            boxPre.setEnabled(false); //Decimal Places
            //Buttons
            buttonCal.setEnabled(false); // Calculate
            buttonGraph.setEnabled(false); // Graph
            buttonReset.setEnabled(false); // Reset
            buttonClear.setEnabled(false); // Clear
            //Labels
            labelsp1.setEnabled(false); // "x0" label
            labelsp2.setEnabled(false); // "x1" label
            //Radio buttons
            f1.setEnabled(true); //x-x^2
            f2.setEnabled(true); //ln(x+1)+1
            //Setting  text area to show nothing
            txtAnswer.setText(""); //Root

        }
    }//GEN-LAST:event_f3ActionPerformed

    private void buttonBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonBackActionPerformed

        //Code for back to menu button
        Secant s = new Secant();
        Menu m = new Menu();
        m.setVisible(true); // set visibitiy for menu frame
        m.setLocationRelativeTo(null); //set location for menu frame
        m.setTitle("Numerical Methods"); // set title for menu frame
        s.setVisible(false); // terminates current frame
        dispose(); // terminates current frame

    }//GEN-LAST:event_buttonBackActionPerformed

    private void buttonResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonResetActionPerformed
//Text Boxes
        boxsp1.setEnabled(false); //x0
        boxsp2.setEnabled(false); //x1
        boxPre.setEnabled(false); //Decimal Places
        //Buttons
        buttonCal.setEnabled(false); //Calculate
        buttonGraph.setEnabled(false); //Graph
        buttonReset.setEnabled(false); //Reset
        buttonClear.setEnabled(false); //Clear
        //Labels
        labelsp1.setEnabled(false); //"x0" label
        labelsp2.setEnabled(false); //"x1" label
        labelPre.setEnabled(false); //"Decimal Places" label
        //Deselects all radiobuttons
        f1.setSelected(false); // x-x^2
        f2.setSelected(false); // ln(x+1)+1
        f3.setSelected(false); // e^x-3x
        //Enables all radiobittons
        f1.setEnabled(true); // x-x^2
        f2.setEnabled(true); // ln(x+1)+1
        f3.setEnabled(true); // e^x-3x
        //Setting both text areas to show nothing
        txtAnswer.setText(""); // Root
        //Set values for text boxes
        boxsp1.setText("0"); //Sets x0 text box to value "0"
        boxsp2.setText("0"); //Sets x1 text box to value "0"
        boxPre.setText("0.00"); //Sets Decimal Places text box to value "0.00"

    }//GEN-LAST:event_buttonResetActionPerformed

    private void boxsp1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxsp1ActionPerformed
        // No code stored
    }//GEN-LAST:event_boxsp1ActionPerformed

    private void buttonGraphActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonGraphActionPerformed

        //This code launches the graph and activates the classes stored in the "Graph" Packages
        javax.swing.JFrame f = new javax.swing.JFrame();
        Applet app = new MultiGraph();
        app.init();
        f.setTitle("Function Plotter"); // set title for graph frame
        f.getContentPane().add(app);
        f.pack();
        f.setSize(new Dimension(1200, 800)); // set dimensions for graph frame
        f.setVisible(true);

    }//GEN-LAST:event_buttonGraphActionPerformed

    private void boxsp2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxsp2ActionPerformed
        // No code stored
    }//GEN-LAST:event_boxsp2ActionPerformed

    private void buttonClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonClearActionPerformed

        //Text boxes
        boxsp1.setEnabled(true); // x0
        boxsp2.setEnabled(true); // x1
        boxPre.setEnabled(true); // Decimal Places
        //Buttons
        buttonCal.setEnabled(true); // Calculate
        buttonGraph.setEnabled(true); // Graph
        buttonReset.setEnabled(true); // Reset
        buttonClear.setEnabled(true); // Clear
        //Labels
        labelsp1.setEnabled(true); // "x0" label
        labelsp2.setEnabled(true); // "x1" label
        labelPre.setEnabled(true); // "Decimal Places" label
        //Setting both text areas to show nothing
        txtAnswer.setText(""); // Root

    }//GEN-LAST:event_buttonClearActionPerformed

    private void boxPreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxPreActionPerformed
        // No code stored
    }//GEN-LAST:event_boxPreActionPerformed

    public static void main(String[] args) {


        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Secant.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Secant.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Secant.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Secant.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {

                new Secant().setVisible(true);

            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private static javax.swing.JTextField boxPre;
    private static javax.swing.JTextField boxsp1;
    private static javax.swing.JTextField boxsp2;
    private javax.swing.JButton buttonBack;
    private javax.swing.JButton buttonCal;
    private javax.swing.JButton buttonClear;
    private javax.swing.JButton buttonExit;
    private javax.swing.JButton buttonGraph;
    private javax.swing.JButton buttonReset;
    private static javax.swing.JRadioButton f1;
    private static javax.swing.JRadioButton f2;
    private static javax.swing.JRadioButton f3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labelPre;
    private javax.swing.JLabel labelTitle;
    private javax.swing.JLabel labelsp1;
    private javax.swing.JLabel labelsp2;
    private javax.swing.JLabel labelsp4;
    private javax.swing.JLabel labelsp5;
    private javax.swing.JPanel panelFunctions;
    private static javax.swing.JTextArea txtAnswer;
    // End of variables declaration//GEN-END:variables
}
