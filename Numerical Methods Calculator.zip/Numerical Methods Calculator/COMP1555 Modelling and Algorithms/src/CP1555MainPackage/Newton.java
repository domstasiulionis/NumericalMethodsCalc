//author ds2182y
package CP1555MainPackage;

//imports
import GraphData.MultiGraph;
import java.applet.Applet;
import java.awt.Dimension;
import java.text.DecimalFormat;
import javax.swing.JOptionPane;

public class Newton extends javax.swing.JFrame {

    public Newton() {
        initComponents();
        /* 
        
         The code below is responsible for disabling objects when the frame is first opened.
        
         */
        // Text boxes
        boxsp1.setEnabled(false); // x0
        boxPre.setEnabled(false); // Decimal Places
        boxDer.setEnabled(false); // Derivative
        //Buttons
        buttonCal.setEnabled(false); // Calculate
        buttonGraph.setEnabled(false); // Graph
        buttonReset.setEnabled(false); //Reset
        buttonClear.setEnabled(false);  //Clear
        //Labels
        labelsp1.setEnabled(false); // "x0" label
        labelpre.setEnabled(false); // "Decimal Places" label
        labelder.setEnabled(false); // "Derivative
        labelIterations.setEnabled(false); // "No. of Iterations" label
        //Spinner
        iterationsSelect.setEnabled(false); // Spinner

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        labelpre = new javax.swing.JLabel();
        buttonCal = new javax.swing.JButton();
        buttonReset = new javax.swing.JButton();
        labelTitle = new javax.swing.JLabel();
        boxsp1 = new javax.swing.JTextField();
        boxPre = new javax.swing.JTextField();
        buttonExit = new javax.swing.JButton();
        buttonGraph = new javax.swing.JButton();
        labelsp1 = new javax.swing.JLabel();
        buttonBack = new javax.swing.JButton();
        panelFunctions = new javax.swing.JPanel();
        f2 = new javax.swing.JRadioButton();
        f1 = new javax.swing.JRadioButton();
        f3 = new javax.swing.JRadioButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtAnswer = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtAnswerIteration = new javax.swing.JTextArea();
        labelsp4 = new javax.swing.JLabel();
        labelsp5 = new javax.swing.JLabel();
        buttonClear = new javax.swing.JButton();
        boxDer = new javax.swing.JTextField();
        labelder = new javax.swing.JLabel();
        iterationsSelect = new javax.swing.JSpinner();
        labelIterations = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        labelpre.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        labelpre.setText("Decimal Place:");

        buttonCal.setText("Calculate");
        buttonCal.setToolTipText("Starts Calculation");
        buttonCal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonCalActionPerformed(evt);
            }
        });

        buttonReset.setText("Reset");
        buttonReset.setToolTipText("Resets the window to default");
        buttonReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonResetActionPerformed(evt);
            }
        });

        labelTitle.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        labelTitle.setText("Newton-Rapshon Method");

        boxsp1.setText("0");
        boxsp1.setToolTipText("Enter starting point");
        boxsp1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxsp1ActionPerformed(evt);
            }
        });

        boxPre.setText("0.00");
        boxPre.setToolTipText("Adjust decimal places of final answer and iterations");

        buttonExit.setBackground(new java.awt.Color(153, 0, 0));
        buttonExit.setForeground(new java.awt.Color(204, 204, 204));
        buttonExit.setText("Exit");
        buttonExit.setToolTipText("Exit the application");
        buttonExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonExitActionPerformed(evt);
            }
        });

        buttonGraph.setText("Graph");
        buttonGraph.setToolTipText("Opens graph");
        buttonGraph.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonGraphActionPerformed(evt);
            }
        });

        labelsp1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        labelsp1.setText("x1 =");

        buttonBack.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        buttonBack.setText("Back");
        buttonBack.setToolTipText("Back to main menu");
        buttonBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonBackActionPerformed(evt);
            }
        });

        panelFunctions.setBackground(new java.awt.Color(204, 204, 204));
        panelFunctions.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        f2.setBackground(new java.awt.Color(204, 204, 204));
        f2.setForeground(new java.awt.Color(0, 0, 0));
        f2.setText("ln(x+1)+1");
        f2.setToolTipText("Function 2");
        f2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                f2ActionPerformed(evt);
            }
        });

        f1.setBackground(new java.awt.Color(204, 204, 204));
        f1.setForeground(new java.awt.Color(0, 0, 0));
        f1.setText("x-x^2");
        f1.setToolTipText("Function 1");
        f1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                f1ActionPerformed(evt);
            }
        });

        f3.setBackground(new java.awt.Color(204, 204, 204));
        f3.setForeground(new java.awt.Color(0, 0, 0));
        f3.setText("e^x-3x");
        f3.setToolTipText("Function 3");
        f3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                f3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelFunctionsLayout = new javax.swing.GroupLayout(panelFunctions);
        panelFunctions.setLayout(panelFunctionsLayout);
        panelFunctionsLayout.setHorizontalGroup(
            panelFunctionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelFunctionsLayout.createSequentialGroup()
                .addGap(54, 54, 54)
                .addComponent(f1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(f2)
                .addGap(86, 86, 86)
                .addComponent(f3)
                .addGap(52, 52, 52))
        );
        panelFunctionsLayout.setVerticalGroup(
            panelFunctionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelFunctionsLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(panelFunctionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(f1)
                    .addComponent(f2)
                    .addComponent(f3))
                .addContainerGap(31, Short.MAX_VALUE))
        );

        txtAnswer.setColumns(20);
        txtAnswer.setRows(5);
        txtAnswer.setToolTipText("Final Root");
        jScrollPane1.setViewportView(txtAnswer);
        txtAnswer.setEditable(false);

        txtAnswerIteration.setColumns(20);
        txtAnswerIteration.setRows(5);
        txtAnswerIteration.setToolTipText("Iterations");
        jScrollPane2.setViewportView(txtAnswerIteration);
        txtAnswerIteration.setEditable(false);

        labelsp4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        labelsp4.setText("--------------------------------------------FUNCTIONS----------------------------------------");

        labelsp5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        labelsp5.setText("---------------------------------------------SETTINGS-----------------------------------------");

        buttonClear.setText("Clear");
        buttonClear.setToolTipText("Clear content in all text boxes");
        buttonClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonClearActionPerformed(evt);
            }
        });

        boxDer.setToolTipText("Derivative of the selected function");
        boxDer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxDerActionPerformed(evt);
            }
        });

        labelder.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        labelder.setText("Derivative =");

        iterationsSelect.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));
        iterationsSelect.setToolTipText("Adjust how many iterations you would like to see");
        iterationsSelect.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        iterationsSelect.setName(""); // NOI18N
        iterationsSelect.setValue(1);

        labelIterations.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        labelIterations.setText("No. of Iterations:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(panelFunctions, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(buttonGraph, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addGap(9, 9, 9)
                                        .addComponent(buttonBack, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(labelTitle))
                                    .addComponent(labelsp4, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(labelsp5, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addGap(20, 20, 20)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(labelsp1)
                                            .addComponent(labelpre)
                                            .addComponent(labelder)
                                            .addComponent(labelIterations))
                                        .addGap(53, 53, 53)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(boxDer)
                                            .addComponent(boxPre)
                                            .addComponent(boxsp1, javax.swing.GroupLayout.DEFAULT_SIZE, 323, Short.MAX_VALUE))))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(iterationsSelect, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(buttonCal, javax.swing.GroupLayout.PREFERRED_SIZE, 381, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(buttonClear, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(buttonReset, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 419, Short.MAX_VALUE))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 419, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(buttonExit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(13, 13, 13))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(labelTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(buttonBack))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(labelsp4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(panelFunctions, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(labelsp5)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(boxsp1, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(labelsp1))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(boxDer, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(labelder))
                                .addGap(17, 17, 17)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(boxPre, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(labelpre))
                                .addGap(16, 16, 16)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(iterationsSelect, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(labelIterations))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(buttonCal, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(buttonClear, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jScrollPane2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(buttonGraph, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                            .addComponent(buttonReset, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(buttonExit, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(11, 11, 11))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //------------------------------------------------------------------------------------------------//
    // Newton-Rapshon Algorithm START                                                                 //
    //------------------------------------------------------------------------------------------------//
    static int iteration = 0; // Declaring iteration variable
    
    public double getf(double x) {

        int maxIterations = (int) iterationsSelect.getValue(); // maxIteration variable takes user selection input from the spinner for he maximum amount of iterations and adjusts it accordingly.

        DecimalFormat df = new DecimalFormat((boxPre.getText())); // Declaring decimal formatting variable

        for (int iteration = 0; iteration < maxIterations; iteration++) { //for loop to display iterative history

            x = x - func(x) / deri(x); //Formula for Newton-Raphson Method
            txtAnswerIteration.append("\nIteration " + iteration + ":   " + df.format(x)); //Prints Iteration history and seperate text box from the final root
        }

        return x;
    }

    private double deri(double x) {
        // Derivatives put on display depending on which function the user has selected (not editable by user)
        if (f3.isSelected()) {
            return Math.exp(x) - 3; // for c function
        } else {
            if (f2.isSelected()) {
                return (1) / x + 1; // for ln(x+1)+1 function
            } else {
                if (f1.isSelected()) {

                }
            }

        }
        return 1 - 2 * x; // for x-x^2 function
    }

    private double func(double x) {
        //if functions to determine which function to return based on user selection via radiobuttons
        if (f3.isSelected()) {
            return Math.exp(x) - 3 * x; // for x-x^2 function
        } else {
            if (f2.isSelected()) {
                return Math.log(x + 1) + 1; // ln(x+1)+1
            } else {
                if (f1.isSelected()) {

                }
            }

        }
        return x - x * x; // x-x^2
    }

    //Main method of this algorithm
    public void nm(javax.swing.JTextArea area) {
        DecimalFormat df = new DecimalFormat((boxPre.getText())); // Declaring decimal format variable
        txtAnswer.setText("Root: " + " " + df.format(getf(Double.parseDouble(boxsp1.getText())))); // Prints root // takes input from x0 text box
    }

    //------------------------------------------------------------------------------------------------//
    // Newton-Raphson Algorithm END                                                                   //
    //------------------------------------------------------------------------------------------------//

    private void buttonCalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonCalActionPerformed

        //User input valdation
        if (boxsp1.getText().equals("")) { //x0
            JOptionPane.showMessageDialog(null, "Please enter starting point(s) "); // Message box to inform the user
        } else {
            if (boxPre.getText().equals("")) { // Decimal Places
                boxsp1.setText(""); // If decimal place box is empty, this line intentionally removes the first starting point to stop the calculation from happening.
                JOptionPane.showMessageDialog(null, "Please enter decimal places & re-enter first starting point "); // Message box to inform the user
            } else {
            }
        }

        nm(txtAnswer); // runs Newton-Raphson code

        //Text boxes
        boxsp1.setEnabled(false); // x0
        boxPre.setEnabled(false); // Decimal Places
        //Buttons
        buttonCal.setEnabled(false); // Calcualte
        buttonGraph.setEnabled(false); // Graph
        //labels
        labelsp1.setEnabled(false); // "x0" label
        labelpre.setEnabled(false); // "Decimal Places" labels
        labelIterations.setEnabled(false); // "No. of Iterations" label
        //Spinner
        iterationsSelect.setEnabled(false); // Spinner
        

    }//GEN-LAST:event_buttonCalActionPerformed

    private void buttonResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonResetActionPerformed

        //Text Boxes
        boxsp1.setEnabled(false); //x0
        boxPre.setEnabled(false); //Decimal Places
        //Buttons
        buttonCal.setEnabled(false); //Calculate
        buttonGraph.setEnabled(false); //Graph
        buttonReset.setEnabled(false); //Reset
        buttonClear.setEnabled(false); //Clear
        //Labels
        labelsp1.setEnabled(false); //"x0" label
        labelpre.setEnabled(false); //"Decimal Places" label
        labelIterations.setEnabled(false); // "No. of Iterations" label
        //Spinner
        iterationsSelect.setEnabled(false); // Spinner 
        //Deselects all radiobuttons
        f1.setSelected(false); // x-x^2
        f2.setSelected(false); // ln(x+1)+1
        f3.setSelected(false); // e^x-3x
        //Enables all radiobittons
        f1.setEnabled(true); // x-x^2
        f2.setEnabled(true); // ln(x+1)+1
        f3.setEnabled(true); // e^x-3x
        //Setting both text areas to show nothing
        txtAnswer.setText(""); // Root
        txtAnswerIteration.setText(""); // Iterations
        //Set values for text boxes
        boxsp1.setText("0"); //Sets x0 text box to value "0"
        boxPre.setText("0.00"); //Sets Decimal Places text box to value "0.00"
        boxDer.setText(""); //Sets Derivative text box to empty

    }//GEN-LAST:event_buttonResetActionPerformed

    private void boxsp1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxsp1ActionPerformed
        // No code stored
    }//GEN-LAST:event_boxsp1ActionPerformed

    private void buttonExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonExitActionPerformed
        System.exit(0); //Terminates the program
    }//GEN-LAST:event_buttonExitActionPerformed

    private void buttonGraphActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonGraphActionPerformed

        //This code launches the graph and activates the classes stored in the "Graph" Packages
        javax.swing.JFrame f = new javax.swing.JFrame();
        Applet app = new MultiGraph();
        app.init();
        f.setTitle("Function Plotter"); // set title for graph frame
        f.getContentPane().add(app);
        f.pack();
        f.setSize(new Dimension(1200, 800)); // set dimensions for graph frame
        f.setVisible(true);

    }//GEN-LAST:event_buttonGraphActionPerformed

    private void buttonBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonBackActionPerformed

        //Code for back to menu button
        Newton n = new Newton();
        Menu m = new Menu();
        m.setVisible(true); // set visibitiy for menu frame
        m.setLocationRelativeTo(null); //set location for menu frame
        m.setTitle("Numerical Methods"); // set title for menu frame
        n.setVisible(false); // terminates current frame
        dispose(); // terminates current frame

    }//GEN-LAST:event_buttonBackActionPerformed

    private void f2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_f2ActionPerformed

        if (f2.isSelected()) { //ln(x+1)+1
            //Text boxes
            boxsp1.setEnabled(true); // x0
            boxPre.setEnabled(true); // Decimal Places
            boxDer.setText("ln(x+1)+1"); // Derivative
            //Buttons
            buttonCal.setEnabled(true); // Calculate
            buttonGraph.setEnabled(true); // Graph
            buttonReset.setEnabled(true); // Reset
            buttonClear.setEnabled(true); // Clear
            //Labels
            labelsp1.setEnabled(true); // "x0" label
            labelpre.setEnabled(true); // "Decimal Places" label
            labelder.setEnabled(false); // "Derivative" label
            labelIterations.setEnabled(true); // "No. of Iterations" label
            //Spinner
            iterationsSelect.setEnabled(true); // Spinner
            //Radio buttons
            f1.setEnabled(false); //x-x^2
            f3.setEnabled(false); //e^x-3x
            //Setting both text areas to show nothing
            txtAnswer.setText(""); //Root  
            txtAnswerIteration.setText(""); // Iterations

        } else {
            //Text boxes
            boxsp1.setEnabled(false); // x0
            boxPre.setEnabled(false); //Decimal Places
            boxDer.setText(""); // Derivative
            //Buttons
            buttonCal.setEnabled(false); // Calculate
            buttonGraph.setEnabled(false); // Graph
            buttonReset.setEnabled(false); // Reset
            buttonClear.setEnabled(false); // Clear
            //Labels
            labelsp1.setEnabled(false); // "x0" label
            labelpre.setEnabled(false); // "Decimal Places" label
            labelIterations.setEnabled(false); // "No. of Iterations" label
            //Spinner
            iterationsSelect.setEnabled(false); // Spinner
            //Radio buttons
            f1.setEnabled(true); //x-x^2
            f3.setEnabled(true); //e^x-3x
            //Setting both text areas to show nothing
            txtAnswer.setText(""); //Root
            txtAnswerIteration.setText(""); // Iterations

        }
    }//GEN-LAST:event_f2ActionPerformed

    private void f1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_f1ActionPerformed

        if (f1.isSelected()) { //x-x^2
            //Text boxes
            boxsp1.setEnabled(true); // x0
            boxPre.setEnabled(true); // Decimal Places
            boxDer.setText("1 - 2 * x"); // Derivative
            //Buttons
            buttonCal.setEnabled(true); // Calculate
            buttonGraph.setEnabled(true); // Graph
            buttonReset.setEnabled(true); // Reset
            buttonClear.setEnabled(true); // Clear
            //Labels
            labelsp1.setEnabled(true); // "x0" label
            labelpre.setEnabled(true); // "Decimal Places" label
            labelder.setEnabled(false); // "Derivative" label
            labelIterations.setEnabled(true); // "No. of Iterations" label
            //Spinner
            iterationsSelect.setEnabled(true); // Spinner
            //Radio buttons
            f2.setEnabled(false); //ln(x+1)+1
            f3.setEnabled(false); //e^x-3x
            //Setting both text areas to show nothing
            txtAnswer.setText(""); //Root
            txtAnswerIteration.setText(""); // Iterations

        } else {
            //Text boxes
            boxsp1.setEnabled(false); // x0
            boxPre.setEnabled(false); //Decimal Places
            boxDer.setText(""); //Derivative
            //Buttons
            buttonCal.setEnabled(false); // Calculate
            buttonGraph.setEnabled(false); // Graph
            buttonReset.setEnabled(false); // Reset
            buttonClear.setEnabled(false); // Clear
            //Labels
            labelsp1.setEnabled(false); // "x0" label
            labelpre.setEnabled(false); // "Decimal Places" label
            labelIterations.setEnabled(false); // "No. of Iterations" label
            //Spinner
            iterationsSelect.setEnabled(false); // Spinner
            //Radio buttons
            f2.setEnabled(true); //ln(x+1)+1
            f3.setEnabled(true); //e^x-3x
            //Setting both text areas to show nothing
            txtAnswer.setText(""); //Root
            txtAnswerIteration.setText(""); // IterationsF

        }
    }//GEN-LAST:event_f1ActionPerformed

    private void f3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_f3ActionPerformed

        if (f3.isSelected()) { //e^x-3x
            //Text boxes
            boxsp1.setEnabled(true); // x0
            boxPre.setEnabled(true); // Decimal Places
            boxDer.setText("e^x-3"); // Derivative
            //Buttons
            buttonCal.setEnabled(true); // Calculate
            buttonGraph.setEnabled(true); // Graph
            buttonReset.setEnabled(true); // Reset
            buttonClear.setEnabled(true); // Clear
            //Labels
            labelsp1.setEnabled(true); // "x0" label
            labelpre.setEnabled(true); // "Decimal Places" label
            labelIterations.setEnabled(true); // "No. of Iterations" label
            //Spinner
            iterationsSelect.setEnabled(true); // Spinner
            //Radio buttons
            f1.setEnabled(false); //x-x^2
            f2.setEnabled(false); //ln(x+1)+1
            //Setting both text areas to show nothing
            txtAnswer.setText(""); //Root
            txtAnswerIteration.setText(""); // Iterations

        } else {
            //Text boxes
            boxsp1.setEnabled(false); // x0
            boxPre.setEnabled(false); //Decimal Places
            boxDer.setText(""); // Derivative
            //Buttons
            buttonCal.setEnabled(false); // Calculate
            buttonGraph.setEnabled(false); // Graph
            buttonReset.setEnabled(false); // Reset
            buttonClear.setEnabled(false); // Clear
            //Labels
            labelsp1.setEnabled(false); // "x0" label
            labelpre.setEnabled(false); // "Decimal Places" label
            labelIterations.setEnabled(false); // "No. of Iterations" label
            //Spinner
            iterationsSelect.setEnabled(false); // Spinner
            //Radio buttons
            f1.setEnabled(true); //x-x^2
            f2.setEnabled(true); //ln(x+1)+1
            //Setting both text areas to show nothing
            txtAnswer.setText(""); //Root
            txtAnswerIteration.setText(""); // Iterations

        }
    }//GEN-LAST:event_f3ActionPerformed

    private void buttonClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonClearActionPerformed

        //Text boxes
        boxsp1.setEnabled(true); // x0
        boxPre.setEnabled(true); // Decimal Places
        //Buttons
        buttonCal.setEnabled(true); // Calculate
        buttonGraph.setEnabled(true); // Graph
        buttonReset.setEnabled(true); // Reset
        buttonClear.setEnabled(true); // Clear
        //Labels
        labelsp1.setEnabled(true); // "x0" label
        labelpre.setEnabled(true); // "Decimal Places" label
        labelIterations.setEnabled(true); // "No. of Iterations" label
        //Spinner
        iterationsSelect.setEnabled(true); // Spinner
        //Setting both text areas to show nothing
        txtAnswer.setText(""); // Root
        txtAnswerIteration.setText(""); // Iterations
    }//GEN-LAST:event_buttonClearActionPerformed

    private void boxDerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxDerActionPerformed
        // No code stored
    }//GEN-LAST:event_boxDerActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Newton.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Newton.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Newton.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Newton.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Newton().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private static javax.swing.JTextField boxDer;
    private static javax.swing.JTextField boxPre;
    private static javax.swing.JTextField boxsp1;
    private javax.swing.JButton buttonBack;
    private static javax.swing.JButton buttonCal;
    private javax.swing.JButton buttonClear;
    private javax.swing.JButton buttonExit;
    private javax.swing.JButton buttonGraph;
    private javax.swing.JButton buttonReset;
    private static javax.swing.JRadioButton f1;
    private static javax.swing.JRadioButton f2;
    private static javax.swing.JRadioButton f3;
    private static javax.swing.JSpinner iterationsSelect;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel labelIterations;
    private javax.swing.JLabel labelTitle;
    private javax.swing.JLabel labelder;
    private javax.swing.JLabel labelpre;
    private javax.swing.JLabel labelsp1;
    private javax.swing.JLabel labelsp4;
    private javax.swing.JLabel labelsp5;
    private javax.swing.JPanel panelFunctions;
    private static javax.swing.JTextArea txtAnswer;
    private static javax.swing.JTextArea txtAnswerIteration;
    // End of variables declaration//GEN-END:variables
}
