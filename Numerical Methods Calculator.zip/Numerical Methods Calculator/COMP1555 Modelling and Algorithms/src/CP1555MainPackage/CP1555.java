//author Ds2182y
package CP1555MainPackage;

//imports
import javax.swing.JFrame;

public class CP1555 {

    public static void main(String[] args) {
                //GUI for Menu
                Menu m = new Menu();
                //Setting Title
                m.setTitle("Numerical Methods");
                //Setting Launch Location (Center)
                m.setLocationRelativeTo(null);
                //Set resizable
                m.setResizable(false);
                //Set Visibility
                m.setVisible(true);
                m.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}

